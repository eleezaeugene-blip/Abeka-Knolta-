const KEY='knolta-v1';
let D={members:[],meetings:{}};
try{const s=localStorage.getItem(KEY);if(s)D=JSON.parse(s)}catch(e){}
let warned=false;const save=()=>{try{localStorage.setItem(KEY,JSON.stringify(D))}catch(e){if(!warned){warned=true;toast('Warning: this browser cannot save your data. Do not use private or incognito mode.')}}};
const $=s=>document.querySelector(s);
const esc=s=>String(s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
const iso=d=>new Date(d.getTime()-d.getTimezoneOffset()*6e4).toISOString().slice(0,10);
const today=()=>iso(new Date());
const fmt=s=>{const[y,m,d]=s.split('-');return new Date(+y,m-1,+d).toLocaleDateString('en-GB',{weekday:'long',day:'numeric',month:'long',year:'numeric'})};
const get=d=>D.meetings[d]||{att:{},minutes:'',time:''};
const M=d=>D.meetings[d]||(D.meetings[d]={att:{},minutes:'',time:''});
const hasAtt=m=>!!m&&Object.keys(m.att||{}).length>0;
const isMtg=d=>{const m=D.meetings[d];return hasAtt(m)||(m.minutes||'').trim()};
const present=m=>Object.values(m.att||{}).filter(Boolean).length;
let tab='home',cur=today(),per='weekly',pdate=today(),aiOut='',aiRep='',delId=null,SA=null,rec=null,recOn=false;
const T=[['home','Home'],['minutes','Minutes'],['attendance','Attendance'],['reports','Reports'],['members','Members']];

function toast(s){const t=$('#toast');t.textContent=s;t.style.display='block';clearTimeout(toast.t);toast.t=setTimeout(()=>t.style.display='none',2800)}
async function copy(t){try{await navigator.clipboard.writeText(t)}catch(e){const x=document.createElement('textarea');x.value=t;document.body.appendChild(x);x.select();try{document.execCommand('copy')}catch(_){}x.remove()}toast('Copied')}
function pr(title,text){$('#pa').innerHTML='<h1>'+esc(title)+'</h1><div class="pre">'+esc(text)+'</div>';setTimeout(()=>{try{window.print()}catch(e){toast('Printing is not available here. Use Copy instead.')}},60)}

function home(){const t=today(),m=get(t),mo=t.slice(0,7);
const ds=Object.keys(D.meetings).filter(isMtg).sort().reverse();
const mm=ds.filter(d=>d.startsWith(mo)),cn=mm.filter(d=>hasAtt(D.meetings[d]));
const avg=cn.length?Math.round(cn.reduce((a,d)=>a+present(D.meetings[d]),0)/cn.length):'–';
return `<div class="card"><div class="mut">Today</div><h2>${fmt(t)}</h2><div class="mut">${hasAtt(m)?present(m)+' present':'Attendance not marked yet'}</div></div>
<div class="two"><button class="btn" data-act="go" data-v="minutes" data-d="${t}">Write minutes</button><button class="btn o" data-act="go" data-v="attendance" data-d="${t}">Mark attendance</button></div>
<div class="two"><div class="card"><div class="mut">Meetings this month</div><h2>${mm.length}</h2></div><div class="card"><div class="mut">Average attendance</div><h2>${avg}</h2></div></div>
<h2>Recent minutes</h2>`+(ds.length?ds.slice(0,5).map(d=>`<button class="row" data-act="go" data-v="minutes" data-d="${d}"><span>${fmt(d)}</span><span class="mut">Open</span></button>`).join(''):'<div class="card mut">No meetings yet. Add your members first, then mark attendance.</div>')}

function minutes(){const m=get(cur);
return `<label class="mut">Date<input class="in" type="date" id="dt" value="${cur}"></label>
<label class="mut">Time started<input class="in" id="tm" value="${esc(m.time||'')}" placeholder="e.g. 2:15 pm"></label>
<div class="mut">${hasAtt(m)?present(m)+' of '+D.members.length+' present (from attendance)':'Attendance not marked for this date'}</div>
<label class="mut">Minutes (type, dictate, or paste your notes). Saved automatically.<textarea class="in ta" id="mt">${esc(m.minutes||'')}</textarea></label>
<div class="two"><button class="btn o" id="vb" data-act="voice">${recOn?'Stop recording':'Record voice'}</button><button class="btn o" data-act="tpl">Insert template</button></div>
<div class="two"><button class="btn o" data-act="copy" data-v="min">Copy</button><button class="btn" data-act="printmin">Print</button></div>`}

function attendance(){const m=get(cur);
return `<label class="mut">Meeting date<input class="in" type="date" id="dt" value="${cur}"></label>`+(D.members.length?`<div class="two"><button class="btn o" data-act="allp">Mark all present</button><button class="btn o" data-act="clr">Clear</button></div>`+D.members.map(b=>{const v=m.att[b.id];return `<div class="row"><span><b>${esc(b.name)}</b>${b.role?`<br><span class="mut">${esc(b.role)}</span>`:''}</span><span class="two" style="flex:none"><button class="pill${v===true?' on':''}" data-act="att" data-id="${b.id}" data-v="1">Present</button><button class="pill${v===false?' no':''}" data-act="att" data-id="${b.id}" data-v="0">Absent</button></span></div>`}).join('')+`<div class="card sb"><span>Present: ${present(m)}</span><span>Absent: ${Object.values(m.att).filter(x=>x===false).length}</span></div><div class="mut">Saved automatically.</div>`:'<div class="card mut">No members yet. Go to Members and add them first.</div>')}

function range(){const d=new Date(pdate+'T00:00');let a,b,l;
if(per==='weekly'){const s=new Date(d);s.setDate(d.getDate()-((d.getDay()+6)%7));const e=new Date(s);e.setDate(s.getDate()+6);a=iso(s);b=iso(e);l='Week: '+s.toLocaleDateString('en-GB',{day:'numeric',month:'short'})+' to '+e.toLocaleDateString('en-GB',{day:'numeric',month:'short',year:'numeric'})}
else if(per==='monthly'){a=pdate.slice(0,7)+'-01';b=pdate.slice(0,7)+'-31';l=d.toLocaleDateString('en-GB',{month:'long',year:'numeric'})}
else{a=pdate.slice(0,4)+'-01-01';b=pdate.slice(0,4)+'-12-31';l='Year '+pdate.slice(0,4)}
return{a,b,l}}
function stats(){const r=range(),ds=Object.keys(D.meetings).filter(d=>d>=r.a&&d<=r.b&&isMtg(d)).sort(),cn=ds.filter(d=>hasAtt(D.meetings[d]));
const rank=D.members.map(b=>({name:b.name,n:cn.filter(d=>D.meetings[d].att[b.id]===true).length})).sort((x,y)=>y.n-x.n||x.name.localeCompare(y.name));
const avg=cn.length?Math.round(cn.reduce((s,d)=>s+present(D.meetings[d]),0)/cn.length):0;
return{r,ds,cn,rank,avg}}
function plain(S){return S.r.l+'\nMeetings held: '+S.ds.length+'\nAverage attendance: '+(S.cn.length?S.avg:'not recorded')+'\n\nMeetings:\n'+S.ds.map(d=>'- '+fmt(d)+': '+(hasAtt(D.meetings[d])?present(D.meetings[d])+' present':'attendance not recorded')).join('\n')+'\n\nMost active members:\n'+S.rank.slice(0,10).map((x,i)=>(i+1)+'. '+x.name+' ('+x.n+' of '+S.cn.length+')').join('\n')}
const repText=()=>aiRep||plain(stats());

function reports(){const S=stats();
return `<div class="two">${['weekly','monthly','yearly'].map(x=>`<button class="pill${x===per?' on':''}" data-act="per" data-v="${x}">${x[0].toUpperCase()+x.slice(1)}</button>`).join('')}</div>
<label class="mut">Pick any date in the period<input class="in" type="date" id="pd" value="${pdate}"></label>
<div class="card"><div class="mut">${S.r.l}</div><h2>Meetings held: ${S.ds.length}</h2><div class="mut">Average attendance: ${S.cn.length?S.avg:'–'}</div></div>`+
(S.ds.length?`<h2>Meetings</h2>`+S.ds.map(d=>`<button class="row" data-act="go" data-v="minutes" data-d="${d}"><span>${fmt(d)}</span><span class="mut">${hasAtt(D.meetings[d])?present(D.meetings[d])+' present':'no attendance'}</span></button>`).join(''):'<div class="card mut">No meetings recorded in this period.</div>')+
(S.cn.length?`<h2>Most active members</h2>`+S.rank.slice(0,10).map((x,i)=>`<div class="card"><div class="sb"><b>${i+1}. ${esc(x.name)}</b><span class="mut">${x.n} of ${S.cn.length}</span></div><div class="bar" style="width:${Math.round(100*x.n/S.cn.length)}%"></div></div>`).join(''):'')+
`<div class="two"><button class="btn o" data-act="copy" data-v="rep">Copy report</button><button class="btn" data-act="printrep">Print report</button></div>`}

function members(){const c=Object.values(D.meetings).filter(hasAtt);
return `<div class="card"><h2>Add a member</h2><label class="mut">Name<input class="in" id="nn"></label><label class="mut">Role (optional)<input class="in" id="nr" placeholder="e.g. Altar server"></label><button class="btn" data-act="add" style="margin-top:8px">Add member</button></div>`+
D.members.map(b=>{const n=c.filter(m=>m.att[b.id]===true).length;return `<div class="row"><span><b>${esc(b.name)}</b><br><span class="mut">${b.role?esc(b.role)+' · ':''}${n} of ${c.length} meetings</span></span><button class="pill${delId===b.id?' no':''}" data-act="del" data-id="${b.id}">${delId===b.id?'Tap again':'Remove'}</button></div>`}).join('')+
`<div class="two"><button class="btn o" data-act="exp">Back up data</button><label class="btn o">Restore<input type="file" id="imp" accept=".json" hidden></label></div><div class="mut">Your data is stored on this phone. Back it up now and then.</div>`}

function render(){$('#nav').innerHTML=T.map(([k,n])=>`<button class="tab${k===tab?' on':''}" data-act="tab" data-v="${k}">${n}</button>`).join('');
$('#app').innerHTML=({home,minutes,attendance,reports,members})[tab]()}

function addMember(){const f=$('#nn'),n=f.value.trim().replace(/\s+/g,' ');
if(!n){toast('Type the member’s name first.');f.focus();return}
if(D.members.some(b=>b.name.toLowerCase()===n.toLowerCase())){toast(n+' is already in the list.');return}
D.members.push({id:Date.now().toString(36)+Math.random().toString(36).slice(2,5),name:n,role:$('#nr').value.trim()});
D.members.sort((x,y)=>x.name.localeCompare(y.name));save();render();toast(n+' added.');$('#nn').focus()}
function voice(){const SR=window.SpeechRecognition||window.webkitSpeechRecognition;
if(!SR){toast('Voice typing is not supported in this browser. Try Chrome.');return}
if(recOn){rec.stop();return}
rec=new SR();rec.lang='en-GB';rec.continuous=true;rec.interimResults=false;
rec.onresult=e=>{let t='';for(let i=e.resultIndex;i<e.results.length;i++)if(e.results[i].isFinal)t+=e.results[i][0].transcript+' ';const ta=$('#mt');if(!ta)return;ta.value+=(ta.value&&!/\s$/.test(ta.value)?' ':'')+t;ta.dispatchEvent(new Event('input',{bubbles:true}))};
rec.onend=()=>{recOn=false;const b=$('#vb');if(b)b.textContent='Record voice'};
rec.onerror=e=>toast('Voice problem: '+e.error);
try{rec.start();recOn=true;$('#vb').textContent='Stop recording'}catch(e){toast('Could not start the microphone.')}}

function exp(){const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([JSON.stringify(D)],{type:'application/json'}));a.download='knolta-backup-'+today()+'.json';document.body.appendChild(a);a.click();a.remove();toast('Backup saved to your downloads.')}

document.addEventListener('click',async e=>{const a=e.target.closest('[data-act]');if(!a)return;const k=a.dataset.act,v=a.dataset.v,id=a.dataset.id;
if(k==='tab'){tab=v;render();scrollTo(0,0)}
else if(k==='go'){tab=v;cur=a.dataset.d;aiOut='';render();scrollTo(0,0)}
else if(k==='att'){M(cur).att[id]=v==='1';save();render()}
else if(k==='allp'){const m=M(cur);D.members.forEach(b=>m.att[b.id]=true);save();render()}
else if(k==='clr'){M(cur).att={};save();render()}
else if(k==='per'){per=v;aiRep='';render()}
else if(k==='add')addMember();
else if(k==='del'){if(delId===id){D.members=D.members.filter(b=>b.id!==id);Object.values(D.meetings).forEach(m=>delete m.att[id]);delId=null;save()}else delId=id;render()}
else if(k==='voice')voice();
else if(k==='tpl'){const m=M(cur);const t='MINUTES OF THE MEETING HELD ON '+fmt(cur).toUpperCase()+'\n\nThe meeting was called to order at '+(m.time||'______')+(hasAtt(m)?', with '+present(m)+' members present':'')+'.\n\nThe opening prayer was led by ______.\n\n(Write what happened in the meeting here.)\n\nUnder Other Matters, ______.\n\nThere being no other business, the meeting was closed with a prayer led by ______. The meeting adjourned at ______.\n\nSubmitted by: ______';m.minutes=(m.minutes?m.minutes+'\n\n':'')+t;save();render()}
else if(k==='copy')copy(v==='ai'?aiOut:v==='rep'?repText():get(cur).minutes);
else if(k==='printmin')pr('Minutes of the meeting held on '+fmt(cur),get(cur).minutes);
else if(k==='printrep')pr(stats().r.l+' report',repText());
else if(k==='exp')exp()});
document.addEventListener('input',e=>{const t=e.target;if(t.id==='mt'){M(cur).minutes=t.value;save()}else if(t.id==='tm'){M(cur).time=t.value;save()}});
document.addEventListener('change',e=>{const t=e.target;
if(t.id==='dt'&&t.value){cur=t.value;aiOut='';render()}
else if(t.id==='pd'&&t.value){pdate=t.value;aiRep='';render()}
else if(t.id==='imp'&&t.files[0]){const r=new FileReader();r.onload=()=>{try{const x=JSON.parse(r.result);if(Array.isArray(x.members)&&x.meetings&&typeof x.meetings==='object'){D=x;save();render();toast('Data restored')}else throw 0}catch(_){toast('That file is not a valid backup.')}};r.readAsText(t.files[0]);t.value=''}});
document.addEventListener('keydown',e=>{if(e.key==='Enter'&&(e.target.id==='nn'||e.target.id==='nr')){e.preventDefault();addMember()}});

render();
try{localStorage.setItem('knolta-test','1');localStorage.removeItem('knolta-test')}catch(e){toast('Warning: this browser cannot save your data. Do not use private or incognito mode.')}
if('serviceWorker' in navigator)window.addEventListener('load',()=>navigator.serviceWorker.register('sw.js').catch(()=>{}));
